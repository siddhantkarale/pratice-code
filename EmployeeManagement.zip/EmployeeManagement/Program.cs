using EmployeeManagement.Data;
using EmployeeManagement.Repository;
using EmployeeManagement.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.InMemory;
 
namespace EmployeeManagement
{
    public class Program
    {
        public static void Main(string[] args) 
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddDbContext<AppDbContext>(
                options=>options.UseInMemoryDatabase("EmployeeDb")
            );  

            builder.Services.AddCors(options => {
                options.AddPolicy("MyCores", builder =>
                {
                    builder.WithOrigins("http://locahost:4200")
                    .AllowAnyMethod()
                    .AllowAnyHeader();
                });
            });

            //Add Employee repository to Dependancy Injection
            builder.Services.AddScoped<IEmployeeRepository, EmployeeRepository>(); 

            builder.Services.AddControllers(); 

            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();
             
            var app = builder.Build();

            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI(c => {
                    c.SwaggerEndpoint("/swagger/v1/swagger.json", "API V1");
                    c.RoutePrefix = string.Empty;
                });
            }

            app.UseCors("MyCores");

            app.MapControllers();

            app.Run();
        }
    }
}
