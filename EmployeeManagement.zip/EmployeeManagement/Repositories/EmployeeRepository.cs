﻿using EmployeeManagement.Data;
using EmployeeManagement.Models;
using EmployeeManagement.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace EmployeeManagement.Repository
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly AppDbContext _context;

        public EmployeeRepository(AppDbContext context)
        {
            _context=context;
        }

        public async Task AddEmployeeAsync(Employee employee)
        {
            await _context.Employees.AddAsync(employee);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteEmployeeAsync(int id)
        {
            var employeeDb = _context.Employees?.FindAsync(id);

            if (employeeDb == null)
            {
                throw new KeyNotFoundException($"Employee with {id} Not Found");
            }

            _context.Remove(employeeDb);
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<Employee>> GetAllAsync()
        {
            return await _context.Employees.ToListAsync();
        }

        public async Task<Employee?> GetByIdAsync(int id)
        {
            return await _context.Employees.FindAsync(id);
        }

        public async Task UpdateEmployeeAsync(Employee employee)
        {
            if(employee == null)
            {
                throw new KeyNotFoundException("Employee Data is Not Found to Update");
            }
            _context.Update(employee);
            await _context.SaveChangesAsync();
        }
    }
}
